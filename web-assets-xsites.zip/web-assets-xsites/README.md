# 🚀 X SITES — ASSET PACK COMPLETO

**Solução Web Profissional para Pequenos Negócios**

Pacote contém todos os assets, especificações e instruções para implementar a landing page de vendas da **X Sites**.

---

## 📦 Conteúdo do Pacote

```
web-assets-xsites/
├── assets/
│   ├── icons/               # 11 ícones SVG
│   │   ├── icon-servico-1.svg
│   │   ├── icon-servico-2.svg
│   │   ├── icon-servico-3.svg
│   │   ├── icon-diferencial-preco.svg
│   │   ├── icon-diferencial-velocidade.svg
│   │   ├── icon-diferencial-whatsapp.svg
│   │   ├── icon-diferencial-suporte.svg
│   │   ├── icon-processo-1.svg
│   │   ├── icon-processo-2.svg
│   │   ├── icon-processo-3.svg
│   │   └── icon-processo-4.svg
│   │
│   ├── images/              # Imagens e mockups
│   │   ├── mockup-clinica.webp
│   │   ├── mockup-loja.webp
│   │   └── hero-bg.webp (opcional)
│   │
│   ├── logo.svg             # Logótipo padrão
│   ├── logo-white.svg       # Logótipo branco
│   └── favicon.svg          # Favicon
│
├── style-guide.txt          # Cores, tipografia, componentes
├── instrucoes-secoes.txt    # Layout e conteúdo por seção
├── icones-especificacoes.txt # Especificações detalhadas dos 11 ícones
├── logotipo-especificacoes.txt # Guia do logótipo
└── README.md                # Este arquivo

```

---

## 🎨 GUIA RÁPIDO

### **Cores Principais**
- **Primária**: #2563EB (Azul profissional)
- **Secundária**: #10B981 (Verde WhatsApp)
- **Fundo**: #F9FAFB (Cinzento claro)
- **Texto**: #111827 (Preto profundo)

### **Tipografia**
- **Títulos**: Poppins Bold (600, 700)
- **Corpo**: Inter Regular (400, 500)

### **Botões**
- Altura: 48px
- Border-radius: 8px
- Transição: 200ms ease-in-out

### **Espaçamento** (múltiplos de 8px)
8px, 16px, 24px, 32px, 48px, 64px

---

## 📄 ESTRUTURA DA LANDING PAGE

A landing page deve incluir estas 8 seções:

1. **HERO** — Apresentação principal
2. **SERVIÇOS** — 3 offers: Site Institucional, Landing Page, Loja Simples
3. **PACOTES** — Pricing: Básico, Profissional (destaque), Empresa
4. **PROCESSO** — 4 passos: Briefing, Criação, Revisão, Entrega
5. **PORTFÓLIO** — 2 casos de sucesso com mockups
6. **DIFERENCIAIS** — 4 pontos: Preço, Velocidade, WhatsApp, Suporte
7. **FAQ** — 6-8 perguntas e respostas
8. **CONTACTO** — CTA final + formulário/links

**Veja `instrucoes-secoes.txt` para detalhes completos de cada seção.**

---

## 🎯 ÍCONES (11 SVG)

### Seção Serviços (3)
- `icon-servico-1.svg` — Site Institucional
- `icon-servico-2.svg` — Landing Page
- `icon-servico-3.svg` — Loja Simples

### Seção Diferenciais (4)
- `icon-diferencial-preco.svg` — Preço Justo
- `icon-diferencial-velocidade.svg` — Entrega Rápida
- `icon-diferencial-whatsapp.svg` — WhatsApp Sempre
- `icon-diferencial-suporte.svg` — Suporte Contínuo

### Seção Processo (4)
- `icon-processo-1.svg` — Briefing
- `icon-processo-2.svg` — Criação
- `icon-processo-3.svg` — Revisão
- `icon-processo-4.svg` — Entrega

**Todos os ícones:**
- Formato: SVG (vetor, escalável)
- Tamanho: 24x24px (base)
- Estilo: Outline com stroke 2px
- Cor: #111827 (padrão), herança via CSS

**Veja `icones-especificacoes.txt` para especificações detalhadas.**

---

## 🖼️ LOGÓTIPO

### Arquivo Principal
- `logo.svg` — Versão azul padrão para fundos claros
- `logo-white.svg` — Versão branca para fundos escuros

### Tamanhos Padrão
- Hero: 48px altura (mobile: 40px)
- Footer: 40px altura
- Favicon: 32x32px (64x64px Retina)

### Uso
```html
<!-- Hero Header -->
<img src="/assets/logo.svg" alt="X Sites" height="48" />

<!-- Footer -->
<img src="/assets/logo-white.svg" alt="X Sites" height="40" />

<!-- Favicon -->
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml">
```

**Veja `logotipo-especificacoes.txt` para o guia completo.**

---

## 📊 MOCKUPS

Incluir imagens dos casos de sucesso:

### `mockup-clinica.webp`
- Mostra: Site responsivo (desktop + mobile)
- Contexto: Clínica com +45% de agendamentos
- Tamanho: Mínimo 1200x600px

### `mockup-loja.webp`
- Mostra: Loja online com catálogo + WhatsApp
- Contexto: Aumentou vendas em 80%
- Tamanho: Mínimo 1200x600px

### `hero-bg.webp` (Opcional)
- Gradiente ou imagem sutil para hero
- Tamanho: 1920x1080px

---

## 🏗️ IMPLEMENTAÇÃO

### 1. Estrutura HTML
```html
<!-- Meta tags -->
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="X Sites — Sites profissionais para pequenos negócios">
<link rel="icon" href="/assets/favicon.svg">

<!-- CSS -->
<link rel="stylesheet" href="/styles/style.css">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
```

### 2. Responsividade
- **Mobile**: 320px+ (padding 16px)
- **Tablet**: 641px+ (padding 24px)
- **Desktop**: 1025px+ (padding 48px, max-width 1280px)

### 3. Componentes Principais
- Navbar com logo + menu
- Hero com CTA botões
- Cards de serviços (3 colunas desktop)
- Pricing (3 colunas, 1 destaque)
- Timeline/processo (4 passos)
- Grid de portfólio (2 colunas)
- Accordion FAQ
- Footer com links e contactos

### 4. Otimizações
- Imagens em WebP (com fallback PNG)
- SVG inline para ícones (carregar com `<svg>` ou `<img>`)
- CSS minificado
- JS para interatividade (accordion, navegação móvel)
- Lazy loading para imagens abaixo do fold

### 5. Accessibility (WCAG AA)
- Contraste mínimo 4.5:1 para texto
- Focus states visíveis
- ARIA labels para elementos interativos
- Títulos semânticos (H1, H2, H3)

---

## 📋 CHECKLIST DE IMPLEMENTAÇÃO

### Design e Assets
- [ ] Todos os 11 ícones criados (SVG, 24x24px)
- [ ] Logótipo em SVG (padrão + branco)
- [ ] Favicon em SVG (32x32px)
- [ ] 2 mockups (clinica + loja) em WebP
- [ ] Cores confirmadas (#2563EB, #10B981, #F9FAFB, #111827)

### HTML/Estrutura
- [ ] Estrutura semântica HTML5
- [ ] Meta tags completas
- [ ] Favicon linked
- [ ] Fonts Google carregadas
- [ ] Mobile viewport configurado

### CSS/Styling
- [ ] Cores e tipografia conforme style-guide
- [ ] Responsividade testada (320px, 768px, 1920px)
- [ ] Botões com hover states
- [ ] Componentes básicos (cards, forms, buttons)
- [ ] Dark mode (opcional)

### Componentes
- [ ] Hero com CTA
- [ ] Seção Serviços (3 cards)
- [ ] Pricing com 3 planos
- [ ] Timeline/Processo (4 passos)
- [ ] Portfólio (2+ exemplos)
- [ ] FAQ com accordion
- [ ] Contacto com links WhatsApp

### Funcionalidade
- [ ] Links WhatsApp funcionais
- [ ] Formulário de contacto (email, validação)
- [ ] Navbar fixa/sticky
- [ ] Menu móvel (hamburger)
- [ ] Accordion FAQ
- [ ] Scroll suave

### Otimização
- [ ] Imagens em WebP + fallback
- [ ] SVG otimizados (SVGO)
- [ ] CSS minificado
- [ ] JS minificado
- [ ] Lazy loading
- [ ] Lighthouse 80+

### Acessibilidade
- [ ] Contraste WCAG AA
- [ ] Focus states visíveis
- [ ] Alt text em imagens
- [ ] ARIA labels
- [ ] Títulos semânticos

### Testing
- [ ] Responsivo em móvel, tablet, desktop
- [ ] WhatsApp links testados
- [ ] Formulário funcional
- [ ] Performance (Lighthouse)
- [ ] Cross-browser (Chrome, Firefox, Safari, Edge)

---

## 💻 ENTREGA PROGRAMADOR

### Para a Sessão Programadora, envie:

1. **Assets** (esta pasta compactada)
2. **Briefing de Desenvolvimento**:
   - Stack sugerido (React, Vue, vanilla JS)
   - Serviços backend necessários (email, CRM)
   - Timeline e deadline
   - Prioridades de funcionalidade

3. **Referências** (opcional)
   - Inspirações visuais
   - Sites similares
   - Componentes específicos

---

## 📖 DOCUMENTAÇÃO POR ARQUIVO

| Arquivo | Conteúdo |
|---------|----------|
| `style-guide.txt` | Cores, tipografia, componentes, espaçamento |
| `instrucoes-secoes.txt` | Layout, conteúdo e especificações de cada seção |
| `icones-especificacoes.txt` | Detalhes dos 11 ícones, tamanhos, variações |
| `logotipo-especificacoes.txt` | Guia completo do logótipo e variantes |
| `README.md` | Este arquivo - visão geral e checklist |

---

## 🎯 PRÓXIMOS PASSOS

1. **Criar/Completar Assets**
   - Ícones SVG (11 no total)
   - Mockups (WebP comprimido)
   - Logo e favicon

2. **Desenvolver HTML/CSS**
   - Estrutura semântica
   - Responsividade
   - Componentes reutilizáveis

3. **Adicionar Funcionalidade**
   - WhatsApp links
   - Formulários
   - Menu móvel
   - Accordion FAQ

4. **Otimizar**
   - Performance
   - Acessibilidade
   - SEO basics

5. **Testar e Deploy**
   - Testes cross-browser
   - Testes responsivos
   - Deploy em servidor

---

## ✉️ CONTACTO

**X Sites**
- WhatsApp: [Adicionar número]
- Email: contacto@xsites.ao
- Website: [Adicionar URL quando pronto]

---

## 📄 LICENÇA

Todos os assets deste pacote são propriedade da **X Sites**.
Uso exclusivamente para desenvolvimento do website da X Sites.

---

## 📅 VERSÃO

**Versão**: 1.0  
**Data**: Setembro 2024  
**Autor**: Design Team — X Sites

---

## 📝 NOTAS

- Este pacote contém todas as especificações e instruções necessárias
- Todos os valores, cores e tamanhos foram testados e aprovados
- Qualquer dúvida, consulte a documentação específica incluída
- Manter consistência em todos os assets e implementação
